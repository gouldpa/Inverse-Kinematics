﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double THY_LEN = 120.0;
        double SHIN_LEN = 160.0;
        double rad_deg = 180.0 / 3.1415;
        double deg_rad = 3.1415 / 180.0;
        double ang_scale = (25.0 * 4096.0) / 360.0;
        string bufc = "111111";
        string bufa = "111111";
        string bufb = "111111";
        public Form1()
        {
            InitializeComponent();
        }

        int x = 0, y = 0;
        int old_x, old_y; int old_kneex; int old_kneey;
        int hipx=300, hipy = 100, kneex = 0, kneey = 0, footx = 0, footy = 250;
        int sfootx = 0;
        int sfooty = 250;
        int old_footx = 0, old_footy = 0;
        double hip_foot_dist = 0;
        double hip_foot_ang = 0;
        double hip_foot_ang_deg = 0;
        double hip_ang = 0;
        double hip_ang_deg = 0;
        double knee_ang = 0;
        double knee_ang_deg = 0;
        double hip_knee_ang = 0;
        double hip_knee_ang_deg = 0;
        int good_leg = 0;
        int started = 0;
        int wheel = 0;
        int counter = 0;
        int speed = 0;

        //double 


        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            try { serialPort1.Open(); }
            catch { }
            x = 100;y = 100;
        }

        private void Zero_btn_Click(object sender, EventArgs e)
        {
            try { serialPort1.Write("z"); }
            catch { }
        }

        private void Down_btn_Click(object sender, EventArgs e)
        {
            footx = 50;
            footy = 260;
        }

        private void Up_btn_Click(object sender, EventArgs e)
        {
            footx = 50;
            footy = 100;
        }

        private void Hip_vsb_Scroll(object sender, ScrollEventArgs e)
        {
        //    hip_ang = hip_vsb.Value*deg_rad;
        }

        private void Start_btn_Click(object sender, EventArgs e)
        {
            started = 1;
            try { serialPort1.Write("w"); }
            catch { }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            counter++;
            if (counter > 10000)
                counter = 0;
            speed = 101-speed_vsb.Value;
            speed_lbl.Text = speed.ToString();
            Slow_Leg();
            Cal_Leg();
            Send_Serial();
            Draw_Leg();

        }
        private void Slow_Leg()
        {
            if (sfootx < footx - speed)
            {
                sfootx += speed;
            }
            else if (sfootx > footx + speed)
            {
                sfootx -= speed;
            }
            else
            {
                sfootx = footx;
            }

            if (sfooty < footy - speed)
            {
                sfooty += speed;
            }
            else if (sfooty > footy + speed)
            {
                sfooty -= speed;
            }
            else
            {
                sfooty = footy;
            }


        }
        private void Send_Serial()
        {
            //hip_ang = hip_vsb.Value * deg_rad;
            if (started == 1)
            {
                bufa = 'b' + ((int)(hip_roll_hsb.Value * ang_scale)).ToString() + ' ';
                hip_roll_lbl.Text = bufa;
                try { serialPort1.Write(bufa); }
                catch { }
            }
            else if (false) // (started == 1)
            {
                if ((counter % 3) == 0)
                {
                    bufb = 'b' + ((int)(((hip_ang * rad_deg)) * -ang_scale)).ToString() + ' ';
                    hip_scale_lbl.Text = bufb;
                    try { serialPort1.Write(bufb); }
                    catch { }
                }
                else if ((counter % 3) == 1)
                {
                    bufc = 'c' + ((int)((180.0 - (knee_ang * rad_deg)) * -ang_scale)).ToString() + ' ';
                    knee_scale_lbl.Text = bufc;
                    try { serialPort1.Write(bufc); }
                    catch { }
                }
                else
                {
                    bufa = 'a' + ((int)(hip_roll_hsb.Value * ang_scale)).ToString() + ' ';
                    hip_roll_lbl.Text = bufa;
                    try { serialPort1.Write(bufa); }
                    catch { }
                }

            }
            else
            {
                try { serialPort1.Write("q"); }
                catch { }
            }
        }

        private void Stop_btn_Click(object sender, EventArgs e)
        {
            started = 0;

        }

        private void Cal_Leg()
        {
            
            hip_foot_dist = (Math.Sqrt((double)(sfootx * sfootx + sfooty * sfooty)));
            if ((hip_foot_dist < (THY_LEN + SHIN_LEN)) && (hip_foot_dist > ( SHIN_LEN-THY_LEN)))
            { 
                hip_foot_ang = Math.Atan((double)sfootx / (double)sfooty);
                hip_foot_ang_deg = hip_foot_ang * rad_deg;
                hip_foot_ang_lbl.Text = hip_foot_ang_deg.ToString();
                hip_foot_dist_lbl.Text = hip_foot_dist.ToString();
                knee_ang = Math.Acos((double)(SHIN_LEN * SHIN_LEN + THY_LEN * THY_LEN - hip_foot_dist * hip_foot_dist) / ((double)(2.0 * SHIN_LEN * THY_LEN)));
                knee_ang_deg = knee_ang * rad_deg;
                knee_ang_lbl.Text = knee_ang_deg.ToString();
                hip_knee_ang = Math.Acos((double)(THY_LEN * THY_LEN + hip_foot_dist * hip_foot_dist - SHIN_LEN * SHIN_LEN) / ((double)(2.0 * THY_LEN * hip_foot_dist)));
                hip_knee_ang_deg = hip_knee_ang * rad_deg;
                hip_knee_ang_lbl.Text = hip_knee_ang_deg.ToString();
                hip_ang = hip_foot_ang + hip_knee_ang;
                hip_ang_deg = hip_ang * rad_deg;
                hip_ang_lbl.Text = hip_ang_deg.ToString();
                kneex = (int)(Math.Sin(hip_ang) * THY_LEN);
                kneey = (int)(Math.Cos(hip_ang) * THY_LEN);
                good_leg = 1;

            }
            else
            {
                good_leg = 0;
            }


        }



        protected override void OnMouseWheel(MouseEventArgs e)
        {
            wheel += e.Delta;
            wheel_lbl.Text = (wheel).ToString();

        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            x = e.X; y = e.Y;
            footx = x - hipx;
            footy = y - hipy;
            //Draw_Leg();
            
        }
        private void Draw_Leg()
        {
            Graphics g = CreateGraphics();
            Pen p = new Pen(Color.Navy,3);
            Pen erase = new Pen(Color.White,3);

            g.DrawLine(erase, hipx, hipy, old_footx+hipx, old_footy+hipy);
            g.DrawLine(erase, hipx, hipy, old_kneex + hipx, old_kneey + hipy);
            g.DrawLine(erase, old_footx+hipx, old_footy+hipy, hipx + old_kneex, hipy + old_kneey);


            g.DrawLine(p, hipx, hipy, sfootx+hipx, sfooty+hipy);

            if (good_leg == 1)
            {
                g.DrawLine(p, sfootx+hipx, sfooty+hipy, hipx + kneex, hipy + kneey);
                g.DrawLine(p, hipx, hipy, hipx + kneex, hipy + kneey);
            }
                old_kneex = kneex; old_kneey = kneey;
                old_footx = sfootx; old_footy = sfooty;
            
        }
    }
}
