﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.knee_lbl = new System.Windows.Forms.Label();
            this.start_btn = new System.Windows.Forms.Button();
            this.stop_btn = new System.Windows.Forms.Button();
            this.hip_foot_dist_lbl = new System.Windows.Forms.Label();
            this.hip_foot_ang_lbl = new System.Windows.Forms.Label();
            this.knee_ang_lbl = new System.Windows.Forms.Label();
            this.hip_knee_ang_lbl = new System.Windows.Forms.Label();
            this.hip_ang_lbl = new System.Windows.Forms.Label();
            this.zero_btn = new System.Windows.Forms.Button();
            this.knee_scale_lbl = new System.Windows.Forms.Label();
            this.hip_scale_lbl = new System.Windows.Forms.Label();
            this.wheel_lbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.up_btn = new System.Windows.Forms.Button();
            this.down_btn = new System.Windows.Forms.Button();
            this.hip_vsb = new System.Windows.Forms.VScrollBar();
            this.hip_roll_hsb = new System.Windows.Forms.HScrollBar();
            this.hip_roll_lbl = new System.Windows.Forms.Label();
            this.speed_vsb = new System.Windows.Forms.VScrollBar();
            this.speed_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.PortName = "COM18";
            this.serialPort1.StopBits = System.IO.Ports.StopBits.Two;
            // 
            // knee_lbl
            // 
            this.knee_lbl.AutoSize = true;
            this.knee_lbl.Location = new System.Drawing.Point(298, 20);
            this.knee_lbl.Name = "knee_lbl";
            this.knee_lbl.Size = new System.Drawing.Size(39, 17);
            this.knee_lbl.TabIndex = 0;
            this.knee_lbl.Text = "knee";
            // 
            // start_btn
            // 
            this.start_btn.Location = new System.Drawing.Point(12, 12);
            this.start_btn.Name = "start_btn";
            this.start_btn.Size = new System.Drawing.Size(75, 23);
            this.start_btn.TabIndex = 1;
            this.start_btn.Text = "start";
            this.start_btn.UseVisualStyleBackColor = true;
            this.start_btn.Click += new System.EventHandler(this.Start_btn_Click);
            // 
            // stop_btn
            // 
            this.stop_btn.Location = new System.Drawing.Point(93, 12);
            this.stop_btn.Name = "stop_btn";
            this.stop_btn.Size = new System.Drawing.Size(75, 23);
            this.stop_btn.TabIndex = 2;
            this.stop_btn.Text = "stop";
            this.stop_btn.UseVisualStyleBackColor = true;
            this.stop_btn.Click += new System.EventHandler(this.Stop_btn_Click);
            // 
            // hip_foot_dist_lbl
            // 
            this.hip_foot_dist_lbl.AutoSize = true;
            this.hip_foot_dist_lbl.Location = new System.Drawing.Point(690, 132);
            this.hip_foot_dist_lbl.Name = "hip_foot_dist_lbl";
            this.hip_foot_dist_lbl.Size = new System.Drawing.Size(111, 17);
            this.hip_foot_dist_lbl.TabIndex = 3;
            this.hip_foot_dist_lbl.Text = "hip_foot_dist_lbl";
            // 
            // hip_foot_ang_lbl
            // 
            this.hip_foot_ang_lbl.AutoSize = true;
            this.hip_foot_ang_lbl.Location = new System.Drawing.Point(690, 178);
            this.hip_foot_ang_lbl.Name = "hip_foot_ang_lbl";
            this.hip_foot_ang_lbl.Size = new System.Drawing.Size(113, 17);
            this.hip_foot_ang_lbl.TabIndex = 4;
            this.hip_foot_ang_lbl.Text = "hip_foot_ang_lbl";
            // 
            // knee_ang_lbl
            // 
            this.knee_ang_lbl.AutoSize = true;
            this.knee_ang_lbl.Location = new System.Drawing.Point(690, 216);
            this.knee_ang_lbl.Name = "knee_ang_lbl";
            this.knee_ang_lbl.Size = new System.Drawing.Size(93, 17);
            this.knee_ang_lbl.TabIndex = 5;
            this.knee_ang_lbl.Text = "knee_ang_lbl";
            // 
            // hip_knee_ang_lbl
            // 
            this.hip_knee_ang_lbl.AutoSize = true;
            this.hip_knee_ang_lbl.Location = new System.Drawing.Point(690, 252);
            this.hip_knee_ang_lbl.Name = "hip_knee_ang_lbl";
            this.hip_knee_ang_lbl.Size = new System.Drawing.Size(120, 17);
            this.hip_knee_ang_lbl.TabIndex = 6;
            this.hip_knee_ang_lbl.Text = "hip_knee_ang_lbl";
            // 
            // hip_ang_lbl
            // 
            this.hip_ang_lbl.AutoSize = true;
            this.hip_ang_lbl.Location = new System.Drawing.Point(690, 288);
            this.hip_ang_lbl.Name = "hip_ang_lbl";
            this.hip_ang_lbl.Size = new System.Drawing.Size(81, 17);
            this.hip_ang_lbl.TabIndex = 7;
            this.hip_ang_lbl.Text = "hip_ang_lbl";
            // 
            // zero_btn
            // 
            this.zero_btn.Location = new System.Drawing.Point(174, 12);
            this.zero_btn.Name = "zero_btn";
            this.zero_btn.Size = new System.Drawing.Size(75, 23);
            this.zero_btn.TabIndex = 8;
            this.zero_btn.Text = "zero";
            this.zero_btn.UseVisualStyleBackColor = true;
            this.zero_btn.Click += new System.EventHandler(this.Zero_btn_Click);
            // 
            // knee_scale_lbl
            // 
            this.knee_scale_lbl.AutoSize = true;
            this.knee_scale_lbl.Location = new System.Drawing.Point(443, 20);
            this.knee_scale_lbl.Name = "knee_scale_lbl";
            this.knee_scale_lbl.Size = new System.Drawing.Size(39, 17);
            this.knee_scale_lbl.TabIndex = 9;
            this.knee_scale_lbl.Text = "knee";
            // 
            // hip_scale_lbl
            // 
            this.hip_scale_lbl.AutoSize = true;
            this.hip_scale_lbl.Location = new System.Drawing.Point(517, 20);
            this.hip_scale_lbl.Name = "hip_scale_lbl";
            this.hip_scale_lbl.Size = new System.Drawing.Size(39, 17);
            this.hip_scale_lbl.TabIndex = 10;
            this.hip_scale_lbl.Text = "knee";
            // 
            // wheel_lbl
            // 
            this.wheel_lbl.AutoSize = true;
            this.wheel_lbl.Location = new System.Drawing.Point(29, 431);
            this.wheel_lbl.Name = "wheel_lbl";
            this.wheel_lbl.Size = new System.Drawing.Size(44, 17);
            this.wheel_lbl.TabIndex = 11;
            this.wheel_lbl.Text = "wheel";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // up_btn
            // 
            this.up_btn.Location = new System.Drawing.Point(12, 87);
            this.up_btn.Name = "up_btn";
            this.up_btn.Size = new System.Drawing.Size(75, 23);
            this.up_btn.TabIndex = 12;
            this.up_btn.Text = "up_btn";
            this.up_btn.UseVisualStyleBackColor = true;
            this.up_btn.Click += new System.EventHandler(this.Up_btn_Click);
            // 
            // down_btn
            // 
            this.down_btn.Location = new System.Drawing.Point(12, 129);
            this.down_btn.Name = "down_btn";
            this.down_btn.Size = new System.Drawing.Size(75, 23);
            this.down_btn.TabIndex = 13;
            this.down_btn.Text = "down";
            this.down_btn.UseVisualStyleBackColor = true;
            this.down_btn.Click += new System.EventHandler(this.Down_btn_Click);
            // 
            // hip_vsb
            // 
            this.hip_vsb.Location = new System.Drawing.Point(925, 63);
            this.hip_vsb.Maximum = 360;
            this.hip_vsb.Minimum = -360;
            this.hip_vsb.Name = "hip_vsb";
            this.hip_vsb.Size = new System.Drawing.Size(44, 415);
            this.hip_vsb.TabIndex = 14;
            this.hip_vsb.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Hip_vsb_Scroll);
            // 
            // hip_roll_hsb
            // 
            this.hip_roll_hsb.Location = new System.Drawing.Point(136, 483);
            this.hip_roll_hsb.Maximum = 90;
            this.hip_roll_hsb.Minimum = -90;
            this.hip_roll_hsb.Name = "hip_roll_hsb";
            this.hip_roll_hsb.Size = new System.Drawing.Size(281, 36);
            this.hip_roll_hsb.TabIndex = 15;
            // 
            // hip_roll_lbl
            // 
            this.hip_roll_lbl.AutoSize = true;
            this.hip_roll_lbl.Location = new System.Drawing.Point(467, 502);
            this.hip_roll_lbl.Name = "hip_roll_lbl";
            this.hip_roll_lbl.Size = new System.Drawing.Size(50, 17);
            this.hip_roll_lbl.TabIndex = 16;
            this.hip_roll_lbl.Text = "hip roll";
            // 
            // speed_vsb
            // 
            this.speed_vsb.LargeChange = 1;
            this.speed_vsb.Location = new System.Drawing.Point(837, 63);
            this.speed_vsb.Name = "speed_vsb";
            this.speed_vsb.Size = new System.Drawing.Size(44, 415);
            this.speed_vsb.TabIndex = 17;
            this.speed_vsb.Value = 100;
            // 
            // speed_lbl
            // 
            this.speed_lbl.AutoSize = true;
            this.speed_lbl.Location = new System.Drawing.Point(842, 483);
            this.speed_lbl.Name = "speed_lbl";
            this.speed_lbl.Size = new System.Drawing.Size(47, 17);
            this.speed_lbl.TabIndex = 18;
            this.speed_lbl.Text = "speed";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(918, 554);
            this.Controls.Add(this.speed_lbl);
            this.Controls.Add(this.speed_vsb);
            this.Controls.Add(this.hip_roll_lbl);
            this.Controls.Add(this.hip_roll_hsb);
            this.Controls.Add(this.hip_vsb);
            this.Controls.Add(this.down_btn);
            this.Controls.Add(this.up_btn);
            this.Controls.Add(this.wheel_lbl);
            this.Controls.Add(this.hip_scale_lbl);
            this.Controls.Add(this.knee_scale_lbl);
            this.Controls.Add(this.zero_btn);
            this.Controls.Add(this.hip_ang_lbl);
            this.Controls.Add(this.hip_knee_ang_lbl);
            this.Controls.Add(this.knee_ang_lbl);
            this.Controls.Add(this.hip_foot_ang_lbl);
            this.Controls.Add(this.hip_foot_dist_lbl);
            this.Controls.Add(this.stop_btn);
            this.Controls.Add(this.start_btn);
            this.Controls.Add(this.knee_lbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label knee_lbl;
        private System.Windows.Forms.Button start_btn;
        private System.Windows.Forms.Button stop_btn;
        private System.Windows.Forms.Label hip_foot_dist_lbl;
        private System.Windows.Forms.Label hip_foot_ang_lbl;
        private System.Windows.Forms.Label knee_ang_lbl;
        private System.Windows.Forms.Label hip_knee_ang_lbl;
        private System.Windows.Forms.Label hip_ang_lbl;
        private System.Windows.Forms.Button zero_btn;
        private System.Windows.Forms.Label knee_scale_lbl;
        private System.Windows.Forms.Label hip_scale_lbl;
        private System.Windows.Forms.Label wheel_lbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button up_btn;
        private System.Windows.Forms.Button down_btn;
        private System.Windows.Forms.VScrollBar hip_vsb;
        private System.Windows.Forms.HScrollBar hip_roll_hsb;
        private System.Windows.Forms.Label hip_roll_lbl;
        private System.Windows.Forms.VScrollBar speed_vsb;
        private System.Windows.Forms.Label speed_lbl;
    }
}

